package com.example.onlinebankingsystem;

public class DataClass {
    AccountHolders a1;
    AccountHolders a2;
    AccountHolders a3;

    public DataClass() {
        Accounts act1 = new Accounts("1",500);
        Accounts act2 = new Accounts("2",900);
        Accounts act3 = new Accounts("3",300);
        a1 = new AccountHolders("Gagandeep kaur","1111",1111);
        a1.add(act1);a1.add(act2);a1.add(act3);
        Accounts act4 = new Accounts("4",500);
        Accounts act5 = new Accounts("5",500);
        a2 = new AccountHolders("Manpreet Kaur","2222",2222);
        a2.add(act4);a2.add(act5);
        Accounts act6 = new Accounts("6",500);
        a3 = new AccountHolders("Emed Sir","3333",3333);
        a3.add(act6);
    }

    public AccountHolders getA1() {
        return a1;
    }

    public void setA1(AccountHolders a1) {
        this.a1 = a1;
    }

    public AccountHolders getA2() {
        return a2;
    }

    public void setA2(AccountHolders a2) {
        this.a2 = a2;
    }

    public AccountHolders getA3() {
        return a3;
    }

    public void setA3(AccountHolders a3) {
        this.a3 = a3;
    }
}
