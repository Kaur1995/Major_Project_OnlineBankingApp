package com.example.onlinebankingsystem;

public class Transactions {
    String accountNumber_To;
    String accountNumber_From;
    String type ;
    double amount;

    public Transactions(String accountNumber_To, String accountNumber_From, String type, double amount) {
        this.accountNumber_To = accountNumber_To;
        this.accountNumber_From = accountNumber_From;
        this.type = type;
        this.amount = amount;
    }

    public String getAccountNumber_To() {
        return accountNumber_To;
    }

    public void setAccountNumber_To(String accountNumber_To) {
        this.accountNumber_To = accountNumber_To;
    }

    public String getAccountNumber_From() {
        return accountNumber_From;
    }

    public void setAccountNumber_From(String accountNumber_From) {
        this.accountNumber_From = accountNumber_From;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
