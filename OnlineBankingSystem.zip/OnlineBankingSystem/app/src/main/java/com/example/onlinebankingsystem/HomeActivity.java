package com.example.onlinebankingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

public class HomeActivity extends AppCompatActivity {
    Button btnLogIn;
    EditText cardNo;
    EditText pinNo;
    static DataClass dc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        dc= new DataClass();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        cardNo = (EditText) findViewById(R.id.accountID);
        pinNo = (EditText) findViewById(R.id.pinCode);
        btnLogIn =  (Button) findViewById(R.id.logInButton);
        btnLogIn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(HomeActivity.this,Dashboard.class);
                if(dc.getA1().getAccessCardNumber().equals(cardNo.getText().toString()) && dc.getA1().getPinCode()==Integer.parseInt(pinNo.getText().toString())){
                    System.out.println(cardNo.getText().toString());
                    intent.putExtra("AcessCardID",dc.getA1().getAccessCardNumber());
                }else if(dc.getA2().getAccessCardNumber().equals(cardNo.getText().toString()) && dc.getA2().getPinCode()==Integer.parseInt(pinNo.getText().toString())){
                    System.out.println(cardNo.getText().toString());

                    intent.putExtra("AcessCardID",cardNo.getText().toString());
                }else if(dc.getA3().getAccessCardNumber().equals(cardNo.getText().toString()) && dc.getA3().getPinCode()==Integer.parseInt(pinNo.getText().toString())){
                    System.out.println(cardNo.getText().toString());

                    intent.putExtra("AcessCardID",cardNo.getText().toString());
                }else{

                }

                startActivity(intent);
            }
        });
    }
}
