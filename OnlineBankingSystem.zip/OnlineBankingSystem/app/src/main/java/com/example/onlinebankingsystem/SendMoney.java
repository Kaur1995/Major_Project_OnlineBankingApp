package com.example.onlinebankingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SendMoney extends AppCompatActivity {
    EditText toAcc;
    EditText fromAcc;
    EditText amountToSend;
    Button  sendButton;
    double from,to;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_money);
        toAcc = (EditText)findViewById(R.id.toAcc);
        fromAcc = (EditText)findViewById(R.id.fromAcc);
        amountToSend = (EditText)findViewById(R.id.amountToSend);
        sendButton = (Button)findViewById(R.id.sendButton);

        sendButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if (fromAcc.getText().toString().equals("1111")){
                    from = HomeActivity.dc.getA1().getListOfAccounts().get(0).getBalance();
                    HomeActivity.dc.getA1().getListOfAccounts().get(0).setBalance(from-Double.valueOf(amountToSend.getText().toString()));
                    System.out.println(HomeActivity.dc.getA1().getListOfAccounts().get(0).getBalance());
                }else if(fromAcc.getText().equals("2222")){
                    from = HomeActivity.dc.getA2().getListOfAccounts().get(0).getBalance();
                    HomeActivity.dc.getA2().getListOfAccounts().get(0).setBalance(from-Double.valueOf(amountToSend.getText().toString()));
                    System.out.println(HomeActivity.dc.getA2().getListOfAccounts().get(0).getBalance());

                }else if(fromAcc.getText().equals("3333")){
                    from = HomeActivity.dc.getA3().getListOfAccounts().get(0).getBalance();
                    HomeActivity.dc.getA3().getListOfAccounts().get(0).setBalance(from-Double.valueOf(amountToSend.getText().toString()));
                    System.out.println(HomeActivity.dc.getA3().getListOfAccounts().get(0).getBalance());

                }

                if (toAcc.getText().toString().equals("1111")){
                    to = HomeActivity.dc.getA1().getListOfAccounts().get(0).getBalance();
                    HomeActivity.dc.getA1().getListOfAccounts().get(0).setBalance(from+to);
                    System.out.println("True");

                }else if(toAcc.getText().equals("2222")){
                    to = HomeActivity.dc.getA2().getListOfAccounts().get(0).getBalance();
                    HomeActivity.dc.getA2().getListOfAccounts().get(0).setBalance(from+to);


                }else if(toAcc.getText().equals("3333")){
                    to = HomeActivity.dc.getA3().getListOfAccounts().get(0).getBalance();
                    HomeActivity.dc.getA3().getListOfAccounts().get(0).setBalance(from+to);

                }
            }
        });

    }
}
