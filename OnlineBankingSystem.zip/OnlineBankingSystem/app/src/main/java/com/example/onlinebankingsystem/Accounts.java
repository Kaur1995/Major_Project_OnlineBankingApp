package com.example.onlinebankingsystem;

import java.util.ArrayList;

public class Accounts {
    String accountID;
    double balance;
    ArrayList<Transactions> listOfTransactions;

    public Accounts(String accountID, double balance) {
        this.accountID = accountID;
        this.balance = balance;
        this.listOfTransactions = new ArrayList<>();
    }

    public String getAccountID() {
        return accountID;
    }

    public void setAccountID(String accountID) {
        this.accountID = accountID;
    }

    public void add(Transactions t){
        listOfTransactions.add(t);
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public ArrayList<Transactions> getListOfTransactions() {
        return listOfTransactions;
    }

    public void setListOfTransactions(ArrayList<Transactions> listOfTransactions) {
        this.listOfTransactions = listOfTransactions;
    }
}
